package com.nucleus;

public class Instructor {

	private int instrucId;
	private String instrucName;
	@Override
	public String toString() {
		return "Instructor [instrucId=" + instrucId + ", instrucName=" + instrucName + "]";
	}
	public int getInstrucId() {
		return instrucId;
	}
	public void setInstrucId(int instrucId) {
		this.instrucId = instrucId;
	}
	public String getInstrucName() {
		return instrucName;
	}
	public void setInstrucName(String instrucName) {
		this.instrucName = instrucName;
	}

	
	
	
	
	
	
	
	
	
	
	
}
