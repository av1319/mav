package com.nucleus;

import java.util.List;

public class Student 
{
private int stdId;
private String stdName;

public Student(int stdId, String stdName, Subject subject) {
	super();
	this.stdId = stdId;
	this.stdName = stdName;
	this.subject = subject;
}


/*public Instructor getInstructor() {
	return instructor;
}
public void setInstructor(Instructor instructor) {
	this.instructor = instructor;
}
public List<Subject> getSubjects() {
	return subjects;
}
public void setSubjects(List<Subject> subjects) {
	this.subjects = subjects;
}*/
private Subject subject;

public Subject getSubject() {
	return subject;
}
public void setSubject(Subject subject) {
	this.subject = subject;
}
public int getStdId() {
	return stdId;
}
public void setStdId(int stdId) {
	this.stdId = stdId;
}
public String getStdName() {
	return stdName;
}
public void setStdName(String stdName) {
	this.stdName = stdName;
}

}
