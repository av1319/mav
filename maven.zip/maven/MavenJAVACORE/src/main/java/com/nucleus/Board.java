package com.nucleus;

public class Board {

	private int boardID;
	private String boardName;
	public int getBoardID() {
		return boardID;
	}
	public void setBoardID(int boardID) {
		this.boardID = boardID;
	}
	public String getBoardName() {
		return boardName;
	}
	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}
	@Override
	public String toString() {
		return "Board [boardID=" + boardID + ", boardName=" + boardName + "]";
	}
	
	
	
}
