package com.nucleus;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;




/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springone.xml");
    
    Student s2=(Student)applicationContext.getBean("s2");
	System.out.println(s2.getStdId()+" "+s2.getStdName());
	
	/*Subject sub1=(Subject)applicationContext.getBean("sub1");
	System.out.println(sub1.getSubId()+" "+sub1.getSubName());*/
    	 
	Subject sub=s2.getSubject();
	System.out.println(sub);
	
	
	Board board=sub.getBoard();
	System.out.println(board);
	
	/*Instructor instructor=s2.getInstructor();
	//System.out.println(instructor.getInstrucId()+" "+instructor.getInstrucName());
	System.out.println(instructor);*/
    
	/*List<Subject> subList=s2.getSubjects();
	System.out.println(subList);
	*/
    }
}
