package com.nucleus;

import java.util.List;
import java.util.Map;

public class Student {
	private int stdId;
	private String stdName;
	private List<String> phoneNo;
	
	
	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", phoneNo=" + phoneNo + ", map=" + map
				+ ", getPhoneNo()=" + getPhoneNo() + ", getMap()=" + getMap() + ", getStdId()=" + getStdId()
				+ ", getStdName()=" + getStdName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	public List<String> getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(List<String> phoneNo) {
		this.phoneNo = phoneNo;
	}
	private Map<Department,Faculty> map;
	
	
	public Map<Department, Faculty> getMap() {
		return map;
	}
	public void setMap(Map<Department, Faculty> map) {
		this.map = map;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	/*public Student(int stdId, String stdName) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
	}*/
	
	
	
	
	
	
	
}
