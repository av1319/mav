package com.nucleus;

public class Faculty {

	private String facultyName;

	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	
	
	
	
	
}
