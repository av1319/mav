package com.nucleus;

import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext applicationContext= new ClassPathXmlApplicationContext("springtwo.xml");
        
       
        Student s2=(Student)applicationContext.getBean("s2");
    	/*System.out.println(s2.getStdId()+" "+s2.getStdName());*/
    	System.out.println(s2.getPhoneNo());
        Map <Department,Faculty> map=s2.getMap();
        
        for (Map.Entry<Department,Faculty> entry : map.entrySet()) {
            System.out.println("Department = " + entry.getKey().getDepartmentName() + ", Faculty = " + entry.getValue().getFacultyName());
        }
    	
    	
    }
}
