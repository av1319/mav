package com.nucleus.july24;



public class Faculty{

	private String facultyName;

	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
/*	@Override
	public void destroy() throws Exception {
		System.out.println("DESTROY BEAN");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("INITIALIZING BEAN");
		
	}*/
	public void m1(){
		
		System.out.println("m1-init method ");
	}
	
	public void m2(){
		System.out.println("m2-destroy method");
	}
	
	
	
	
}
