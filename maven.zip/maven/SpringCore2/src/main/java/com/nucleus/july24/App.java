package com.nucleus.july24;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App {

	
	public static void main(String[] args) {
		
		/*ApplicationContext applicationContext= new ClassPathXmlApplicationContext("springthree.xml");*/
		AbstractApplicationContext applicationContext= new ClassPathXmlApplicationContext("springthree.xml");
/*		Student s1=(Student)applicationContext.getBean("s1");
		Student s2=(Student)applicationContext.getBean("s2");
		
		System.out.println(s1.getStdId()+" "+s1.getStdName());
		System.out.println(s2.getStdId()+" "+s2.getStdName());*/
		
		/*Student s3=(Student) applicationContext.getBean("s3");
		
		System.out.println(s3.getStdId()+" "+s3.getStdName()+" "+s3.getFaculty().getFacultyName());*/
		
		Faculty f1=(Faculty)applicationContext.getBean("sub1");
		f1.getFacultyName();
		applicationContext.registerShutdownHook(); 
		
		
		
	}
	
	
	
	
	
	
}
