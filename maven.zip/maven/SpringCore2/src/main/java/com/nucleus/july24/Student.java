package com.nucleus.july24;

import java.util.List;
import java.util.Map;

public class Student {
	private int stdId;
	private String stdName;
	
	private Faculty faculty;
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	
	
	
	
	
	
	
	
}
